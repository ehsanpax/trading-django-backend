from django.apps import AppConfig


class Mt5Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mt5'
